def serviceAlreadyExist(errorMessage):
    print("The service already exist")
    print(errorMessage)


